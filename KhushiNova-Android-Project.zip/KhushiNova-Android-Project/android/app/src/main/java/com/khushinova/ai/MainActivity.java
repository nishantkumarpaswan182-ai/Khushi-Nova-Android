package com.khushinova.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
