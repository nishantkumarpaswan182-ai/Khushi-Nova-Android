KHUSHI NOVA — ANDROID BUILD BUNDLE

This archive contains the synced Capacitor Android project and its bundled web UI.
The current KHUSHI NOVA interface and behavior were not changed for this export.

BUILD REQUIREMENTS
- Android Studio with Android SDK Platform 36 installed
- JDK 21
- Internet access for Gradle to download its wrapper distribution and Android dependencies

BUILD IN ANDROID STUDIO
1. Extract this archive.
2. Open the extracted android/ folder as a project in Android Studio.
3. Let Gradle sync, then run the app or choose Build > Build Bundle(s) / APK(s) > Build APK(s).

BUILD FROM A TERMINAL
Linux/macOS:
  cd android
  ./gradlew assembleDebug

Windows:
  cd android
  gradlew.bat assembleDebug

The debug APK is written to:
  android/app/build/outputs/apk/debug/app-debug.apk

BUNDLE CONTENTS
- android/: generated Android app, Gradle settings/build files, wrapper, and synced web assets
- node_modules/@capacitor/android/: the Capacitor Android library referenced by the Gradle project

The Gradle settings are adjusted only in this exported copy to resolve the bundled Capacitor
library from ../node_modules. No files in the original project were changed for this ZIP.
The prebuilt web bundle is in android/app/src/main/assets/public/. Rebuilding the web UI or
running Capacitor sync requires the full KHUSHI NOVA source project.

NETWORK NOTE
The app keeps HTTP enabled for the existing local Termux bridge. For remote connections,
use HTTPS or a trusted network.
